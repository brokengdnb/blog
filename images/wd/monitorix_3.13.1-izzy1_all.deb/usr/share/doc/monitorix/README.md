Monitorix
=========
Monitorix is a free, open-source, lightweight system monitoring tool designed to monitor as many services and system resources as possible.

Community
---------
- [Website](https://www.monitorix.org)
- [Documentation](https://www.monitorix.org/documentation.html)
- [Mailing List](https://lists.sourceforge.net/lists/listinfo/monitorix-general)
- [IRC](https://webchat.freenode.net/?channels=monitorix)

License
-------
Monitorix is free software licensed under the terms of the GNU General Public License version 2 (GPLv2).

Credits
-------
Monitorix was created by [Jordi Sanfeliu](https://www.fibranet.cat).
You can contact me at [jordi@fibranet.cat](mailto:jordi@fibranet.cat).
